// JavaScript Document


function contaCaracteres(){
	
	document.forms[0].elements[1].value = document.forms[0].elements[0].value.length+1;
	
	}